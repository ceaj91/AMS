# RISCV_VHDL
**Development of simple RV32I instruction set processor core**
Code will be written in VHDL.
RV32I - Base Integer Instruction Set, 32-bit registers


